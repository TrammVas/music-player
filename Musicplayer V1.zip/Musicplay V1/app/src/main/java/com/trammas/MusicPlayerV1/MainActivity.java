package com.trammas.MusicPlayerV1;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.text.Layout;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
	private MediaPlayer mediaplayer;
	private boolean isPrepared = false;
	private ArrayList<String> songList;
	private ArrayList<String> pathList;
	private ArrayAdapter<String> songsAdapter;
	private ArrayAdapter<String> sortByAdapter;
	private ListView listView;
	private Boolean isHidden = false;
	private String[] sortByArray = { "Asc", "Desc", "New", "Old" };
	private String order = "Asc";
	private Random random = new Random();
	private String currentSong = null;
	private boolean queue= true;
	private static final int REQUEST_CODE = 123;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mediaplayer = new MediaPlayer();
		mediaplayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
			@Override
			public void onCompletion(MediaPlayer mp){
				if(queue && pathList.indexOf(currentSong)!=0){
					int index=pathList.indexOf(currentSong)+1;
				playAudio(pathList.get(index));
				
				}
			}
		});
		songList = new ArrayList<>();
		pathList = new ArrayList<>();
		songsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, songList);
		sortByAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, sortByArray);
		sortByAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		listView = findViewById(R.id.songListView);
		listView.setAdapter(songsAdapter);
		listView.setOnItemClickListener((parent, view, position, id) -> {
			String selectedSong = pathList.get(position);
			playAudio(selectedSong);
		});

		Button playButton = findViewById(R.id.playButton);
		playButton.setOnClickListener(v -> playAudio(currentSong));
		
		Button randomButton = findViewById(R.id.randomButton);
		randomButton.setOnClickListener(v -> playAudio( pathList.get(random.nextInt(pathList.size()))));

		Button pauseButton = findViewById(R.id.pauseButton);
		pauseButton.setOnClickListener(v -> pauseAudio());

		Button stopButton = findViewById(R.id.stopButton);
		stopButton.setOnClickListener(v -> stopAudio());

		Button queryButton = findViewById(R.id.queryButton);
		queryButton.setOnClickListener(v -> loadSongs());

		Spinner sortByButton = findViewById(R.id.sortByButton);
		sortByButton.setAdapter(sortByAdapter);
		sortByButton.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				String selectedItem = parent.getItemAtPosition(position).toString();
				Toast.makeText(MainActivity.this, "Selected: " + selectedItem, Toast.LENGTH_SHORT).show();
				order=selectedItem;
				isHidden= false;
				Toast.makeText(MainActivity.this, order, Toast.LENGTH_SHORT);
				loadSongs();
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> parent){
				Toast.makeText(MainActivity.this, "Selected: Nothing " ,Toast.LENGTH_SHORT);
				}
		});
		if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) !=PackageManager.PERMISSION_GRANTED){
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},REQUEST_CODE );
		}
	}
	

	private void playAudio(String selectedSong) {
		stopAudio();
		if (!isPrepared)
			try {
				if (selectedSong == null){
					//loads the songs and initiazes the list data on first run
					songQuery(MediaStore.Audio.Media.TITLE + " ASC");
					selectedSong = pathList.get(random.nextInt(pathList.size()));
				}
				mediaplayer.setDataSource(selectedSong);
				mediaplayer.prepare();
				isPrepared = true;
				currentSong = selectedSong;

			} catch (IOException e) {
				e.printStackTrace(); // Log the error for debugging
				Toast.makeText(MainActivity.this, "Error playing audio", Toast.LENGTH_SHORT).show();
				return;
			}
		//reseting the music incase a switch or a pause occurs
		if (mediaplayer.isPlaying() || mediaplayer.getCurrentPosition()>0) {
			mediaplayer.reset();
			isPrepared = false;
			playAudio(selectedSong);
		}
		mediaplayer.start();
	}

	//pause audio
	private void pauseAudio() {
		if (mediaplayer.isPlaying()) {
			mediaplayer.pause();

		}
	}
	//stop + release resources
	private void stopAudio() {
		if (mediaplayer.isPlaying()) {
			mediaplayer.stop();
			mediaplayer.reset();
			isPrepared = false;
		}
	}

	//loads songs for the list element
	private void loadSongs() {
		if (isHidden) {
			listView.setVisibility(View.GONE);
			isHidden = !isHidden;
			return;
		}
		listView.setVisibility(View.VISIBLE);
		isHidden = !isHidden;
		//manage the the outcomes and order organizing
		String sortBy = MediaStore.Audio.Media.DATE_ADDED + " DESC";
		switch (order){
			case "Asc": sortBy = MediaStore.Audio.Media.TITLE + " ASC";
			break;
			case "Desc": sortBy = MediaStore.Audio.Media.TITLE + " DESC";
			break;
			case "New": sortBy = MediaStore.Audio.Media.DATE_ADDED + " DESC";
			break;
			case "Old": sortBy = MediaStore.Audio.Media.DATE_ADDED + " ASC";
			break;
			default: sortBy = MediaStore.Audio.Media.TITLE + " DESC"; 
			break;
		}
		songQuery(sortBy);
	}
	
	//Does a query regarding title,place and informs the adapter
	private void songQuery(String sortBy){
		String[] projection = { MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.TITLE };
		String selection = MediaStore.Audio.Media.IS_MUSIC + " !=0";
		Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection,
				null, sortBy);
		if (cursor != null) {
			songList.clear();
			pathList.clear();
			while (cursor.moveToNext()) {
				String title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
				String data = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));
				songList.add(title); // + " - "+  data);
				pathList.add(data);
			}
		}
		cursor.close();
		songsAdapter.notifyDataSetChanged();

	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grant_results){
		super.onRequestPermissionsResult(requestCode,permissions,grant_results);
		if (requestCode==REQUEST_CODE){
			if(grant_results.length>0 && grant_results[0]==PackageManager.PERMISSION_GRANTED)
					{
						loadSongs();
					}
			else {
				Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
			}
		}
		
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (mediaplayer != null) {
			mediaplayer.release();
			mediaplayer = null;

		}
	}
	
}
